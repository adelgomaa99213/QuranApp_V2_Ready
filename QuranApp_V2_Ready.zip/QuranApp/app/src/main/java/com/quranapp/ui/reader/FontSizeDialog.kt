package com.quranapp.ui.reader

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.quranapp.ui.theme.Gold
import com.quranapp.ui.theme.GoldSoft

const val MIN_FONT_UNIT = 20
const val MAX_FONT_UNIT = 80

/** نافذة اختيار حجم الخط: من 20 إلى 80 وحدة بخطوة 2 (Radio Buttons) مع إبراز الخيار الحالي بالذهبي. */
@Composable
fun FontSizeDialog(current: Int, onSelect: (Int) -> Unit, onDismiss: () -> Unit) {
    val sizes = remember { (MIN_FONT_UNIT..MAX_FONT_UNIT step 2).toList() }
    val listState = rememberLazyListState(
        initialFirstVisibleItemIndex = (sizes.indexOf(current) - 2).coerceAtLeast(0)
    )
    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(20.dp),
        containerColor = MaterialTheme.colorScheme.surface,
        title = { Text("حجم الخط", color = Gold, fontWeight = FontWeight.Bold) },
        text = {
            LazyColumn(state = listState, modifier = Modifier.heightIn(max = 320.dp)) {
                items(sizes) { size ->
                    val selected = size == current
                    Row(
                        Modifier.fillMaxWidth()
                            .selectable(selected = selected, role = Role.RadioButton) { onSelect(size) }
                            .padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = selected, onClick = null,
                            colors = RadioButtonDefaults.colors(
                                selectedColor = Gold, unselectedColor = GoldSoft.copy(alpha = 0.6f)
                            )
                        )
                        Spacer(Modifier.width(12.dp))
                        Text(
                            "$size", fontSize = 18.sp,
                            color = if (selected) Gold else MaterialTheme.colorScheme.onSurface,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                    HorizontalDivider(color = Gold.copy(alpha = 0.15f))
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء", color = Gold) } }
    )
}

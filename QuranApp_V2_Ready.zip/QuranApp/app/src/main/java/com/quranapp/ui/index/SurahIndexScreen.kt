package com.quranapp.ui.index

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.quranapp.data.*
import com.quranapp.ui.reader.ReaderViewModel
import com.quranapp.ui.theme.Gold
import com.quranapp.ui.theme.GoldSoft
import com.quranapp.ui.theme.LocalQuranFont

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SurahIndexScreen(vm: ReaderViewModel, onOpen: (surah: Int, ayah: Int?) -> Unit, onSettings: () -> Unit) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val load by vm.loadState.collectAsStateWithLifecycle()
    val index by vm.index.collectAsStateWithLifecycle()
    val list by vm.filteredIndex.collectAsStateWithLifecycle()
    val query by vm.query.collectAsStateWithLifecycle()
    val last by vm.lastRead.collectAsStateWithLifecycle()
    val bookmarks by vm.bookmarks.collectAsStateWithLifecycle()
    val dark = s.dark ?: isSystemInDarkTheme()
    var tab by rememberSaveable { mutableStateOf(0) }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            topBar = {
                Column {
                    TopAppBar(
                        title = { Text("القرآن الكريم", color = Gold, fontFamily = LocalQuranFont.current, fontSize = 26.sp) },
                        actions = {
                            IconButton({ vm.setDark(!dark) }) {
                                Icon(if (dark) Icons.Default.LightMode else Icons.Default.DarkMode, "الوضع", tint = Gold)
                            }
                            IconButton(onSettings) { Icon(Icons.Default.Settings, "الضبط", tint = Gold) }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
                    )
                    TabsRow(listOf("السور", "الأجزاء", "الإشارات المرجعية"), tab) { tab = it }
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when (val st = load) {
                    LoadState.Loading -> CircularProgressIndicator(Modifier.align(Alignment.Center), color = Gold)
                    is LoadState.Error -> Column(
                        Modifier.align(Alignment.Center).padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(st.message, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurface)
                        Spacer(Modifier.height(16.dp))
                        Button(
                            onClick = vm::reload,
                            colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Color.Black)
                        ) { Text("إعادة المحاولة") }
                    }
                    LoadState.Ready -> when (tab) {
                        0 -> SurahList(list, query, vm::setQuery, last, onOpen, showSearch = true)
                        1 -> JuzList(index, onOpen)
                        else -> BookmarksList(bookmarks, onOpen) { vm.toggleBookmark(it.surah, it.ayah) }
                    }
                }
            }
        }
    }
}

/* ------------------------- مكوّنات مشتركة ------------------------- */

@Composable
internal fun TabsRow(titles: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface)) {
        titles.forEachIndexed { i, t ->
            val sel = i == selected
            Column(
                Modifier.weight(1f).clickable { onSelect(i) }.padding(top = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    t, fontSize = 15.sp, fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal,
                    color = if (sel) Gold else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                )
                Spacer(Modifier.height(10.dp))
                Box(Modifier.height(3.dp).fillMaxWidth().background(if (sel) Gold else Color.Transparent))
            }
        }
    }
}

@Composable
internal fun SurahList(
    list: List<SurahInfo>, query: String, onQuery: (String) -> Unit,
    last: LastRead?, onOpen: (Int, Int?) -> Unit, showSearch: Boolean,
) {
    LazyColumn(Modifier.fillMaxWidth(), contentPadding = PaddingValues(16.dp)) {
        if (showSearch) item {
            OutlinedTextField(
                value = query, onValueChange = onQuery, singleLine = true,
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                placeholder = { Text("ابحث باسم السورة أو رقمها") },
                leadingIcon = { Icon(Icons.Default.Search, null, tint = Gold) },
                trailingIcon = {
                    if (query.isNotEmpty()) IconButton({ onQuery("") }) { Icon(Icons.Default.Close, "مسح", tint = Gold) }
                },
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Gold, unfocusedBorderColor = GoldSoft.copy(alpha = 0.5f), cursorColor = Gold
                )
            )
        }
        if (last != null && query.isBlank()) item { ResumeCard(last) { onOpen(last.surahNumber, last.ayah) } }
        items(list, key = { it.number }) { info -> SurahRow(info) { onOpen(info.number, null) } }
        if (list.isEmpty()) item {
            Text("لا توجد نتائج", Modifier.fillMaxWidth().padding(32.dp), textAlign = TextAlign.Center, color = GoldSoft)
        }
        if (showSearch) item {
            Text(
                "نص المصحف والتفسير الميسر (مجمع الملك فهد): مشروع تنزيل Tanzil — tanzil.net",
                Modifier.fillMaxWidth().padding(vertical = 24.dp),
                textAlign = TextAlign.Center, fontSize = 12.sp, color = GoldSoft
            )
        }
    }
}

@Composable
private fun ResumeCard(last: LastRead, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Gold.copy(alpha = 0.12f)),
        border = BorderStroke(1.dp, Gold)
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.MenuBook, null, tint = Gold)
            Spacer(Modifier.width(12.dp))
            Column {
                Text("متابعة القراءة", color = Gold, fontWeight = FontWeight.Bold)
                Text("سورة ${last.surahName} — الآية ${QuranMarks.ar(last.ayah)}", color = MaterialTheme.colorScheme.onSurface)
            }
        }
    }
}

@Composable
private fun NumberBadge(n: Int) {
    Box(Modifier.size(42.dp).border(1.5.dp, Gold, CircleShape), contentAlignment = Alignment.Center) {
        Text(QuranMarks.ar(n), color = Gold, fontSize = 15.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun SurahRow(info: SurahInfo, onClick: () -> Unit) {
    Column {
        Row(
            Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            NumberBadge(info.number)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(info.name, fontFamily = LocalQuranFont.current, fontSize = 24.sp, color = MaterialTheme.colorScheme.onSurface)
                Text("${QuranMarks.ar(info.ayahCount)} آية", fontSize = 13.sp, color = GoldSoft)
            }
        }
        HorizontalDivider(color = Gold.copy(alpha = 0.2f))
    }
}

/** الأجزاء: اضغط السهم لعرض الأحزاب والأرباع، وأيقونة المصحف لفتح بداية الجزء. */
@Composable
internal fun JuzList(index: List<SurahInfo>, onOpen: (Int, Int?) -> Unit) {
    var expanded by rememberSaveable { mutableStateOf(-1) }
    fun nameOf(s: Int) = index.firstOrNull { it.number == s }?.name ?: ""
    LazyColumn(Modifier.fillMaxWidth(), contentPadding = PaddingValues(16.dp)) {
        items(30) { j ->
            val k = QuranMarks.juzStarts[j]
            val s = k / 1000
            val a = k % 1000
            Column {
                Row(
                    Modifier.fillMaxWidth().clickable { expanded = if (expanded == j) -1 else j }.padding(vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    NumberBadge(j + 1)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text("الجزء ${QuranMarks.juzNames[j]}", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                        Text("يبدأ من سورة ${nameOf(s)} · آية ${QuranMarks.ar(a)}", fontSize = 13.sp, color = GoldSoft)
                    }
                    IconButton({ onOpen(s, a) }) { Icon(Icons.Default.MenuBook, "فتح", tint = Gold) }
                    Icon(if (expanded == j) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, tint = Gold)
                }
                AnimatedVisibility(expanded == j) {
                    Column(Modifier.padding(start = 56.dp, bottom = 8.dp)) {
                        val from = j * 8
                        val to = minOf(from + 8, QuranMarks.rubStarts.size)
                        if (from >= to) {
                            Text("بيانات الأحزاب والأرباع غير متوفرة لهذا الجزء", fontSize = 13.sp, color = GoldSoft)
                        } else for (i in from until to) {
                            val rk = QuranMarks.rubStarts[i]
                            val rs = rk / 1000
                            val ra = rk % 1000
                            Text(
                                "الحزب ${QuranMarks.ar(QuranMarks.hizbOf(i + 1))} · الربع ${QuranMarks.ar(QuranMarks.quarterOf(i + 1))} — ${nameOf(rs)} ${QuranMarks.ar(ra)}",
                                Modifier.fillMaxWidth().clickable { onOpen(rs, ra) }.padding(vertical = 8.dp),
                                fontSize = 15.sp, color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
                HorizontalDivider(color = Gold.copy(alpha = 0.2f))
            }
        }
    }
}

/** الإشارات المرجعية: نص الآية كما هو في المصحف مع السورة ورقم الآية والجزء. */
@Composable
internal fun BookmarksList(marks: List<BookmarkItem>, onOpen: (Int, Int?) -> Unit, onRemove: (BookmarkItem) -> Unit) {
    if (marks.isEmpty()) {
        Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
            Text(
                "لا توجد إشارات مرجعية بعد.\nاضغط مطولاً على أي آية أثناء القراءة لإضافتها.",
                textAlign = TextAlign.Center, color = GoldSoft, lineHeight = 26.sp
            )
        }
        return
    }
    LazyColumn(Modifier.fillMaxWidth(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        items(marks, key = { "${it.surah}:${it.ayah}" }) { b ->
            Card(
                onClick = { onOpen(b.surah, b.ayah) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, Gold.copy(alpha = 0.5f))
            ) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("سورة ${b.surahName} · الآية ${QuranMarks.ar(b.ayah)}", color = Gold, fontWeight = FontWeight.Bold)
                            Text("الجزء ${QuranMarks.ar(b.juz)}", fontSize = 13.sp, color = GoldSoft)
                        }
                        IconButton({ onRemove(b) }) { Icon(Icons.Default.Delete, "حذف", tint = GoldSoft) }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        b.text, fontFamily = LocalQuranFont.current, fontSize = 24.sp, lineHeight = 44.sp,
                        textAlign = TextAlign.Justify, color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}

/** الانتقال السريع بين السور والأجزاء من شاشة القراءة. */
@Composable
fun QuickNavDialog(index: List<SurahInfo>, onGo: (Int, Int?) -> Unit, onDismiss: () -> Unit) {
    var tab by remember { mutableStateOf(0) }
    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(20.dp),
        containerColor = MaterialTheme.colorScheme.surface,
        title = { Text("الانتقال السريع", color = Gold, fontWeight = FontWeight.Bold) },
        text = {
            Column {
                TabsRow(listOf("السور", "الأجزاء"), tab) { tab = it }
                Box(Modifier.fillMaxWidth().heightIn(max = 420.dp)) {
                    if (tab == 0) SurahList(index, "", {}, null, onGo, showSearch = false) else JuzList(index, onGo)
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onDismiss) { Text("إغلاق", color = Gold) } }
    )
}

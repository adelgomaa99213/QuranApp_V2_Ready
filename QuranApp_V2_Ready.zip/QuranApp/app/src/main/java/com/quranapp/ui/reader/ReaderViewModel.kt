package com.quranapp.ui.reader

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.quranapp.data.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.FileNotFoundException

/** ViewModel واحد مشترك (نطاق Activity) بين شاشة الفهرس وشاشة القراءة. */
class ReaderViewModel(app: Application) : AndroidViewModel(app) {
    private val settingsRepo = SettingsRepository(app)
    private val quran = QuranRepository(app)

    val settings = settingsRepo.flow.stateIn(viewModelScope, SharingStarted.Eagerly, Settings())

    val loadState = MutableStateFlow<LoadState>(LoadState.Loading)
    val index = MutableStateFlow<List<SurahInfo>>(emptyList())
    val query = MutableStateFlow("")
    val filteredIndex = combine(index, query) { l, q -> QuranRepository.filter(l, q) }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val lastRead = combine(settings, index) { st, idx ->
        idx.firstOrNull { it.number == st.lastSurah }?.let { LastRead(it.number, it.name, st.lastAyah) }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val opened = MutableStateFlow<Opened?>(null)
    val hasMeanings = MutableStateFlow(false)

    /** الإشارات المرجعية (بلا حد): نص الآية كما في المصحف + السورة والآية والجزء، الأحدث أولاً. */
    val bookmarks = combine(settings, index) { st, idx ->
        if (idx.isEmpty()) emptyList() else st.bookmarks.mapNotNull { b ->
            val p = b.split(":")
            if (p.size < 3) return@mapNotNull null
            val s = p[0].toIntOrNull() ?: return@mapNotNull null
            val a = p[1].toIntOrNull() ?: return@mapNotNull null
            val name = idx.firstOrNull { it.number == s }?.name ?: return@mapNotNull null
            BookmarkItem(s, name, a, QuranMarks.juzOf(s, a), quran.ayahText(s, a) ?: "", p[2].toLongOrNull() ?: 0L)
        }.sortedByDescending { it.time }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    init { reload() }

    fun reload() {
        viewModelScope.launch {
            loadState.value = LoadState.Loading
            loadState.value = try {
                index.value = quran.load().index
                hasMeanings.value = quran.hasMeanings
                LoadState.Ready
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                LoadState.Error(describe(e))
            }
        }
    }

    private fun describe(e: Exception) = when (e) {
        is FileNotFoundException -> "لم يُعثر على ملف quran.json داخل app/src/main/assets (راجع README)"
        is IllegalStateException -> "ملف quran.json فارغ أو غير صالح"
        else -> "تعذّر قراءة بيانات المصحف (${e.javaClass.simpleName})"
    }

    fun setQuery(q: String) { query.value = q }

    /** يفتح السورة فوراً من الذاكرة (الفهرس لا يظهر إلا بعد اكتمال التحميل). */
    fun openSurah(number: Int, ayah: Int? = null) {
        val s = quran.surahOrNull(number) ?: return
        opened.value = Opened(s, ayah)
    }

    fun saveProgress(surah: Int, ayah: Int) {
        viewModelScope.launch { settingsRepo.setLastRead(surah, ayah) }
    }

    fun meaningOf(word: String): String? = quran.meaning(word)

    suspend fun tafsirOf(surah: Int, ayah: Int): String? = quran.tafsir(surah, ayah)

    fun toggleBookmark(surah: Int, ayah: Int) = viewModelScope.launch { settingsRepo.toggleBookmark(surah, ayah) }
    fun setTafsirSource(v: String) = viewModelScope.launch { settingsRepo.setTafsirSource(v) }
    fun setFont(v: Int) = viewModelScope.launch { settingsRepo.setFont(v) }
    fun setDark(v: Boolean) = viewModelScope.launch { settingsRepo.setDark(v) }
    fun setBg(v: Int) = viewModelScope.launch { settingsRepo.setBg(v) }
    fun setSpeed(v: Float) = viewModelScope.launch { settingsRepo.setSpeed(v) }
}

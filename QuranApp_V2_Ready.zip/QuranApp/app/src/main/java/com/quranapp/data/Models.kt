package com.quranapp.data

data class Ayah(val number: Int, val text: String)

/** basmala: تُملأ لكل السور عدا الفاتحة (آيتها الأولى) والتوبة. */
data class Surah(val number: Int, val name: String, val ayahs: List<Ayah>, val basmala: String? = null)

/** بيانات خفيفة لشاشة الفهرس. */
data class SurahInfo(val number: Int, val name: String, val ayahCount: Int)

data class QuranData(val surahs: List<Surah>, val index: List<SurahInfo>)

/** السورة المفتوحة حالياً + الآية التي يبدأ منها القارئ (null = من البداية). */
data class Opened(val surah: Surah, val startAyah: Int?)

data class BookmarkItem(
    val surah: Int, val surahName: String, val ayah: Int, val juz: Int, val text: String, val time: Long,
)

data class LastRead(val surahNumber: Int, val surahName: String, val ayah: Int)

sealed interface LoadState {
    object Loading : LoadState
    object Ready : LoadState
    data class Error(val message: String) : LoadState
}
